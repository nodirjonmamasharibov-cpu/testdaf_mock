# TestDaF-Training

A static website with 24 practice tests for the digital TestDaF: 12 × Lesen and 12 × Hören.
No build step, no server code, no database. Any static host can serve it.

## Folder structure

```
index.html            Home page with all 24 tests
lesen/                12 Lesen tests (modelltest-1.html … modelltest-12.html)
hoeren/               12 Hören tests
hoeren/audio/1 … 12/  MP3 audio for each Hören test
fonts/                Self-hosted fonts (no requests to Google)
vercel.json           Optional: long caching for audio and fonts on Vercel
```

Scores are saved only in the visitor's browser (localStorage). Nothing is sent anywhere.

## Option 1: Netlify Drop (easiest, about 2 minutes)

1. Unzip `testdaf-website.zip`.
2. Open https://app.netlify.com/drop and log in (free account).
3. Drag the unzipped `testdaf-website` folder onto the page.
4. You get a live address like `https://something.netlify.app`. You can rename it under *Site configuration → Change site name*.

## Option 2: Vercel with GitHub

1. Create a new repository on GitHub.
2. Upload the **contents** of the unzipped folder (so `index.html` is at the top level).
   GitHub's web upload accepts 100 files at a time. This site has more, so upload in two rounds
   (for example the `hoeren` folder first, then everything else), or use GitHub Desktop.
3. On https://vercel.com choose *Add New → Project*, import the repository,
   set *Framework Preset* to **Other**, leave the build command empty, and click *Deploy*.

## Option 3: Vercel from the command line

If Node.js is installed, open a terminal inside the unzipped folder and run:

```
npx vercel --prod
```

## Notes

- The audio files total about 45 MB. Free plans on Netlify, Vercel and Cloudflare Pages handle this easily.
- If you share the site publicly in Germany, check whether you need an *Impressum* and a privacy notice.
- This is practice material and not an official product of the TestDaF-Institut.

## Updating a test later

Every test is a single file, so you never have to rebuild the whole site:

- Lesen: `lesen/modelltest-N.html`
- Hören: `hoeren/modelltest-N.html` (its audio is in `hoeren/audio/N/`)

On GitHub, open the folder, choose *Add file → Upload files*, upload the new file with exactly the same name, and click *Commit changes*. Vercel publishes the change automatically within about a minute.
